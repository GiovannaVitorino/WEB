package br.edu.ifspcjo.ads.web2.task.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import br.edu.ifspcjo.ads.web2.task.model.Task;
import br.edu.ifspcjo.ads.web2.task.model.User;

public class TaskDao {

	private DataSource dataSource;

	public TaskDao(DataSource dataSource) {
		this.dataSource = dataSource;
	}
	
	public Boolean save(Task task) {
		String sql = "insert into activity (activity_date, user_id) values(?,?)";
		try (Connection con = dataSource.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
			ps.setString(1, task.getDescription());
			ps.setDate(2, Date.valueOf(task.getDate()));
			ps.setLong(5, task.getUser().getId());
			ps.executeUpdate();
			return true;
		} catch (SQLException sqlException) {
			throw new RuntimeException("Erro ao inserir dados", sqlException);
		}
	}



public List<Task> getTasksByUser(User user) {
	String sql = "select * from activity where user_id=?";
	List<Task> tasks = new ArrayList<>();
	try (Connection con = dataSource.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
		ps.setLong(1, user.getId());
		try (ResultSet rs = ps.executeQuery()) {
			while (rs.next()) {
				Task task = new Task();
				task.setId(rs.getLong(1));
				task.setDate(LocalDate.parse(rs.getDate(3).toString()));
				task.setUser(user);
				tasks.add(task);
			}
		}
		return tasks;
	} catch (SQLException sqlException) {
		throw new RuntimeException("Erro durante a consulta", sqlException);
	}
}}
